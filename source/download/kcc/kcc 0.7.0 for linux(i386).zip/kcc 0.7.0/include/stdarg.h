/*	stdarg.h

	Definitions for accessing parameters in functions that accept
	a variable number of arguments.

	Copyright (c) KK 2011,2021
	All Rights Reserved.
*/
#ifndef _STDDEF_H
#define _STDDEF_H

#if __STDC__
#define _Cdecl
#else
#define _Cdecl	cdecl
#endif

#define va_list void*

#define va_start(ap, parmN)	(ap = ...)
#define va_arg(ap, type)	(*((type *)(ap))++)
#define va_end(ap)
#define _va_ptr			(...)

#endif

