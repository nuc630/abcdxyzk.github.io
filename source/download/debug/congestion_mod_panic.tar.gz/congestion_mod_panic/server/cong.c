#include <linux/mm.h>
#include <linux/module.h>
#include <linux/sysctl.h>
#include <linux/kernel.h>
#include <net/tcp.h>
#include <linux/version.h>

//#define NOT_PANIC

#ifdef NOT_PANIC
#define MM 1000007
struct hash_t {
	struct list_head list;
	u64 val;
};

struct list_head hash[MM];
spinlock_t hash_lock[MM];

void add_addr_to_hash(u64 val)
{
	u32 h = (u32)(val%MM);
	struct hash_t *info = kmalloc(sizeof(struct hash_t), GFP_ATOMIC);;
	INIT_LIST_HEAD(&info->list);
	info->val = val;
	spin_lock(&hash_lock[h]);
	list_add(&info->list, &hash[h]);
	spin_unlock(&hash_lock[h]);
}

int del_addr_from_hash(u64 val)
{
	u32 h = (u32)(val%MM);
	struct hash_t *info;
	spin_lock(&hash_lock[h]);
	list_for_each_entry(info, &hash[h], list) {
		if (info->val == val) {
			list_del(&info->list);
			kfree(info);
			spin_unlock(&hash_lock[h]);
			return 0;
		}
	}
	spin_unlock(&hash_lock[h]);
	printk("unhash val=%lx\n", (unsigned long)val);
	return -1;
}
#endif

struct cong_t {
	u32 buf[14];
	unsigned char *alloc;
};

static void cong_init(struct sock *sk)
{
	struct cong_t *cong = inet_csk_ca(sk);
	cong->alloc = kmalloc(10, GFP_ATOMIC);
	if (!cong->alloc)
		return;
	memset(cong->alloc, 0, 10);
	printk("init %lx\n", (unsigned long)cong->alloc);
#ifdef NOT_PANIC
	add_addr_to_hash((u64)(cong->alloc));
#endif
}

static void cong_release(struct sock *sk)
{
	struct cong_t *cong = inet_csk_ca(sk);
	printk("release %lx\n", (unsigned long)cong->alloc);
#ifdef NOT_PANIC
	if (!del_addr_from_hash((u64)(cong->alloc)))
#endif
		if(cong->alloc) {
			kfree(cong->alloc);
		}
	cong->alloc = NULL;
}

static u32 ssthresh(struct sock *sk)
{
	return 3;
}

static void cong_avoid(struct sock *sk, u32 ack, u32 in_flight)
{
}

static struct tcp_congestion_ops cong_test = {
	.init		= cong_init,
	.release	= cong_release,
	.ssthresh	= ssthresh,
	.cong_avoid	= cong_avoid,
	.owner		= THIS_MODULE,
	.name		= "cong",
	
};

static int __init cong_register(void)
{
#ifdef NOT_PANIC
	int i;
	for (i = 0; i < MM; i++) {
		INIT_LIST_HEAD(&hash[i]);
		spin_lock_init(&hash_lock[i]);
	}
#endif
	printk("struct cong_t size = %lu  kernel limit size = %lu\n", sizeof(struct cong_t), ICSK_CA_PRIV_SIZE);
	BUILD_BUG_ON(sizeof(struct cong_t) > ICSK_CA_PRIV_SIZE);

	return tcp_register_congestion_control(&cong_test);		
}

static void __exit cong_unregister(void)
{
	tcp_unregister_congestion_control(&cong_test);
}

module_init(cong_register);
module_exit(cong_unregister);
MODULE_AUTHOR("cong");
MODULE_LICENSE("GPL");
MODULE_DESCRIPTION("cong");
