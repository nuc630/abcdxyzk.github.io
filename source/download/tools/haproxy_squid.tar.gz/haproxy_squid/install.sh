#!/bin/sh

mkdir -p /tmp/hap
mkdir -p /tmp/hap/var/spool/squid
cp -rf * /tmp/hap

chown -R squid:squid /tmp/hap

/tmp/hap/squid -z -f /tmp/hap/squid.conf

/tmp/hap/squid -f /tmp/hap/squid.conf
